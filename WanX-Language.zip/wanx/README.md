# WanX Programming Language

**WanX** is an original programming language created from scratch.

It uses a completely unique vocabulary and syntax that does not copy Python, JavaScript, or any other major language.

## Unique Keywords

| Action              | WanX Keyword |
|---------------------|--------------|
| Print / Output      | `pulse`      |
| Create variable     | `forge`      |
| Conditional         | `probe`      |
| True branch         | `path`       |
| False branch        | `shadow`     |
| End of block        | `close`      |
| True / False        | `yes` / `no` |
| Comments            | `::`         |

## Example

```wanx
:: Hello from WanX

pulse "Welcome to WanX!"

forge name = "Creator"
pulse "Hello, " + name

forge a = 15
forge b = 7

probe a > b path
    pulse "a is bigger"
shadow
    pulse "b is bigger or equal"
close
```

## How to Run

You need Python 3 installed.

### Run a file:
```bash
python wanx.py examples/hello.wanx
```

### Interactive mode (REPL):
```bash
python wanx.py
```

## Project Structure

```
wanx/
├── wanx.py          → Main runner
├── lexer.py         → Tokenizer
├── parser.py        → Parser
├── interpreter.py   → Executor
├── examples/
│   └── hello.wanx
└── README.md
```

## Current Features (v0.2)

- Variables (`forge`)
- Output (`pulse`)
- Arithmetic (`+ - * /`)
- Comparisons (`== != < > <= >=`)
- Strings + concatenation
- Conditionals (`probe ... path ... shadow ... close`)
- Comments (`::`)
- Interactive REPL

More features (loops, functions, lists...) can be added later.

---

Created with original design. This is **your** language.
